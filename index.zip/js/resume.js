$(document).ready(() => {
    $("#resume_view").hide();
})

var image_path = '';
function readURL(input) {
    debugger;
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            image_path = e.target.result;
            console.log(image_path);
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function input_validation(id, msg) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const textbox_val = $(id).val();
    if (textbox_val == "" || textbox_val == null) {
        $(id + '_required').show();
        $(id + '_required').html(msg);
        return false;
    } else {
        if (id == "#email") {
            if ($(id).val().match(re)) {
                $(id + '_required').hide();
                $(id + '_required').html("Required");
                return 1;
            } else {
                $(id + '_required').show();
                $(id + '_required').html("Email is not valid");
                return false;
            }
        } else {
            $(id + '_required').hide();
            $(id + '_required').html("Required");
            return 1;
        }
    }
}

var file_validation = 1;
var fileName = '';
$(".custom-file-input").on("change", function () {
    debugger;
    var file_val = $(this).val().split("\\").pop().split('.')[1];
    if (file_val == "jpg" || file_val == "png") {
        fileName = $(this).val().split("\\").pop();
        file_validation = 1;
        $("#profileimg_required").hide();
        $("label.custom-file-label").text(fileName);
        readURL(this);
    } else {
        fileName = '';
        file_validation = false;
        $("#profileimg_required").text("Image should be JPG or PNG");
        $("#profileimg_required").show();
        $("label.custom-file-label").text("Choose Image");
    }
});


$("#submit_form").click(function (event) {
    const hobbies_chek = [];
    $("input:checkbox[name='hobbies']:checked").each(function () {
        hobbies_chek.push($(this).val());
    });
    var hobbies_val = 1;
    if (hobbies_chek.length >= 1) {
        hobbies_val = 1;
        $("#hobbies_required").hide();
    } else {
        hobbies_val = 0;
        $("#hobbies_required").show();
    }

    if ($("input[name='gender']:checked").val() == undefined || $("input[name='gender']:checked").val() == "" || $("input[name='gender']:checked").val() == null) {
        $("#gender_required").show();
    } else {
        $("#gender_required").hide();
    }

    var email = input_validation('#email', 'Please enter email');   
    if (file_validation == 1 && hobbies_val == 1 && email == 1) {
        var load_json = {
            "first_name": $("#fname").val(),
            "last_name": $("#lname").val(),
            "emailid": $("#email").val(),
            "mobileno": $("#mobile").val(),
            "gender": $("input[name='gender']:checked").val(),
            "State": $("#State").val(),
            "city": $("#City").val(),
            "education": $("#education").val(),
            "hobbies": hobbies_chek,
            "career_objective": $("#objective").val(),
            "profile_image": image_path
        }

        resume_detail(load_json);

        $('html, body').animate({
            scrollTop: $("#resume_view").offset().top
        }, 1000);

        clearvalues();
    }

});

function clearvalues() {
    $("#fname").val('');
    $("#lname").val('');
    $("#email").val('');
    $("#mobile").val('');
    $("input[name='gender']").prop("checked", false);
    $("#State").val('');
    $("#City").val('');
    $("#education").val('');
    $("#objective").val('');
    $("input[name='hobbies']").prop("checked", false);
    $("#profileimg").val('');
    $("label.custom-file-label").text("Choose Image");
}

function resume_detail(data) {    
    $("#fname_view").text(data.first_name);
    $("#lname_view").text(data.last_name);
    $("#email_view").text(data.emailid);
    $("#mobile_view").text(data.mobileno);
    $("#gender_view").text(data.gender);
    $("#State_view").text(data.State);
    $("#City_view").text(data.city);
    $("#education_view").text(data.education);
    var hobies_list = '';
    data.hobbies.forEach(item => {
        hobies_list += item + ", ";
    });
    $("#hobbies_view").text(hobies_list);
    $("#objective_view").text(data.career_objective);
    $("#profileimg_view").attr('src', data.profile_image);
    $("#resume_view").show();

}